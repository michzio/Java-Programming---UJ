package start;
import java.util.*;

public class HelloWorldConsole {
 public static void main(String[] arg) {
 	System.out.println("To jest pierwszy program testowy.");
    System.out.println(new Date());
 }
}
