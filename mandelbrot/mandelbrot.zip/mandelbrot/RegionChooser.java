package mandelbrot;

interface RegionChooser { 
	public void regionChoosen(int x1, int x2, int y1, int y2);
}
